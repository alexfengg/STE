Compute SVD of an out-of-core matrix.
See testpca.m for examples.
Yoel Shkolnisky, February 2011.
